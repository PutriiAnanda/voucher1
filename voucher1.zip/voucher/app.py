from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient

connection_string = 'mongodb+srv://test:sparta@cluster0.xuhvihs.mongodb.net/?retryWrites=true&w=majority'
client = MongoClient(connection_string)
db = client.secret

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/v1', methods=['GET'])
def show_v1():
    articles = list(db.v1.find({},{'_id':False}))
    return jsonify({'articles': articles})

@app.route('/v1', methods=['POST'])
def save_v1():
    #sample_receive = request.form['sample_give']
    #print(sample_receive)
    title_receive = request.form.get('title_give')
    content_receive = request.form.get('content_give')
    doc = {
        'title': title_receive,
        'content': content_receive
    }
    db.v1.insert_one(doc)
    return jsonify({'msg': 'Data tersimpan!'})

if __name__ == '__main__':
    app.run('0.0.0.0', port=1000, debug=True)